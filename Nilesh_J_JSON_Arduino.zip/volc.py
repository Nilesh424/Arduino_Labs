import serial
import time
import requests
import sys
import glob
import serial.tools.list_ports as COMs
from serial import SerialException


def send_command(ser, command):
    ser.write(command.encode())

  
def check_ack(ser, ack_string): 
    while(1):
        recd_ack = ser.readline().decode('utf-8')   # Read and print the received serial transmission
        print(recd_ack)
        
        if (recd_ack == ack_string + "\r\n"):   # Check if the recieved message is an acknowledgement message
            print(ack_string + " received")
            break


def port_search():
    if sys.platform.startswith('win'): # Windows
        ports = ['COM{0:1.0f}'.format(ii) for ii in range(1,256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        ports = glob.glob('/dev/tty[A-Za-z]*')
    elif sys.platform.startswith('darwin'): # MAC
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Machine Not pyserial Compatible')

    arduinos = []
    for port in ports: # loop through to determine if accessible
        if len(port.split('Bluetooth'))>1:
            continue
        try:
            ser = serial.Serial(port)
            ser.close()
            arduinos.append(port) # if we can open it, consider it an arduino
        except (OSError, serial.SerialException):
            pass
    return arduinos




def get_volcano_data():
    r = requests.get('https://api.geonet.org.nz/volcano/val')
    data = r.json()
    #print(r.status_code)
    #print(data)
    feature = data['features']
    #print (feature)
    volcano = []
    level = []
    
    for result in feature:
        properties = result['properties']
        volcano.append(properties['volcanoID'])
        level.append(properties['level'])

    # print (volcano)
    # print(level)
    
    return volcano, level




def main():
    arduino_ports = port_search()
    ser = serial.Serial(arduino_ports[0],baudrate=9600) # match baud on Arduino
    ser.flush() # clear the port
    time.sleep(2)

    while(1):
        print("Retrieving latest volcano data")
        volcano, level = get_volcano_data()
        for index in range(0, len(volcano)):
            send_command(ser, "COM_VOLCANO_LEVEL")
            check_ack(ser, "ACK_VOLCANO_LEVEL")
            print("Displaying " + volcano[index] + ": " + str(level[index]))
            send_command(ser, str(level[index]))
            check_ack(ser, "ACK_VOLCANO_LEVEL")

if __name__ == "__main__":
    main()